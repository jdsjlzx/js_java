package com.tamic.jswebview.browse;


public interface BridgeHandler {

    void handler(String data, CallBackFunction function);

}
