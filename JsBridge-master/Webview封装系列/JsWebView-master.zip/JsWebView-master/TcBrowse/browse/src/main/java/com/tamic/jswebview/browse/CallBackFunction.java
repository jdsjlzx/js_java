package com.tamic.jswebview.browse;

public interface CallBackFunction {

    public void onCallBack(String data);

}
