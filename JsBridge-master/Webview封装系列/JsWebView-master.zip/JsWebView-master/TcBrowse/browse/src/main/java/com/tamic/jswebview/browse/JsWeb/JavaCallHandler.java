package com.tamic.jswebview.browse.JsWeb;

/**
 * Class description
 *
 * @author YEZHENNAN220
 * @date 2016-07-08 17:36
 */
public interface JavaCallHandler {

    public void OnHandler(String handlerName, String jsResponseData);
}
