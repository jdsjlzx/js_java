package com.just.library;

/**
 * Created by cenxiaozhong on 2017/5/30.
 */

public interface WebLifeCycle {


    void onResume();
    void onPause();
    void onDestroy();


}
