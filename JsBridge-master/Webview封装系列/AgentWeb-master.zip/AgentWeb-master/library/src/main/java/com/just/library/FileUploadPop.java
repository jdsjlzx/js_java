package com.just.library;

/**
 * Created by cenxiaozhong on 2017/5/22.
 */

public interface FileUploadPop<T> {

    T pop();


}
