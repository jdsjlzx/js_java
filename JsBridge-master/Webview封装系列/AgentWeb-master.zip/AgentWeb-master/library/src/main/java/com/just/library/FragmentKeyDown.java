package com.just.library;

import android.view.KeyEvent;

/**
 * Created by cenxiaozhong
 * source code  https://github.com/Justson/AgentWeb
 */

public interface FragmentKeyDown {

    boolean onFragmentKeyDown(int keyCode, KeyEvent event);
}
