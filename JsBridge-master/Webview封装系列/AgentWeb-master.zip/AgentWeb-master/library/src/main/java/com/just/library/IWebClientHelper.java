package com.just.library;

/**
 * Created by cenxiaozhong on 2017/6/10.
 * 这个接口主要是服务 WebViewClient  ， 处理一些常用固定的业务的
 */

public interface IWebClientHelper {
}
