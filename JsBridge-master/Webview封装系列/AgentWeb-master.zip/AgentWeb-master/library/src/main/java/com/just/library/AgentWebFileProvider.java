package com.just.library;

import android.support.v4.content.FileProvider;

/**
 * Created by cenxiaozhong on 2017/5/25.
 */

public class AgentWebFileProvider extends FileProvider {

}
