package com.just.library;

/**
 * Created by cenxiaozhong on 2017/6/10.
 */

public interface EventInterceptor {

    boolean event();

}
