package com.just.library;

/**
 * Created by cenxiaozhong on 2017/5/24.
 */

public interface AgentWebCompat {
}
