package com.just.library;

import android.widget.FrameLayout;

/**
 * Created by cenxiaozhong on 2017/5/12.
 */

public interface LayoutParamsOffer<T extends FrameLayout.LayoutParams> {

    T offerLayoutParams();

}
