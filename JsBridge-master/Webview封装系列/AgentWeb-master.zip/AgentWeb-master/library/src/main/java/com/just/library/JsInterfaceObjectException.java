package com.just.library;

/**
 * Created by cenxiaozhong on 2017/5/13.
 */

public class JsInterfaceObjectException extends RuntimeException {
    JsInterfaceObjectException(String msg){
        super(msg);
    }
}
