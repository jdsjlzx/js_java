package com.just.library;

/**
 * Created by cenxiaozhong on 2017/7/5.
 */

public interface Provider<T> {


   T provide();
}
