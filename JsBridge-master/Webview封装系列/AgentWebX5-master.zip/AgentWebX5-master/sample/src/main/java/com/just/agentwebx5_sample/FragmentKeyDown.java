package com.just.agentwebx5_sample;

import android.view.KeyEvent;

/**
 * Created by cenxiaozhong on 2017/5/23.
 */

public interface FragmentKeyDown {

    boolean onFragmentKeyDown(int keyCode, KeyEvent event);
}
