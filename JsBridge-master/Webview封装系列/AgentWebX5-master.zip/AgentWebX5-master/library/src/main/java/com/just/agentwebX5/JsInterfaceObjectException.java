package com.just.agentwebX5;

/**
 * Created by cenxiaozhong on 2017/5/13.
 * source CODE  https://github.com/Justson/AgentWebX5
 */

public class JsInterfaceObjectException extends RuntimeException {
    JsInterfaceObjectException(String msg){
        super(msg);
    }
}
