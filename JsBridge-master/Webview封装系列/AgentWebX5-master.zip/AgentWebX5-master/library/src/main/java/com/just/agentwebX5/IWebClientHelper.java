package com.just.agentwebX5;

/**
 * Created by cenxiaozhong on 2017/6/10.
 * 这个接口主要是服务 WebViewClient  ， 处理一些常用固定的业务的
 * source CODE  https://github.com/Justson/AgentWebX5
 */

public interface IWebClientHelper {
}
