package com.just.agentwebX5;

import android.widget.FrameLayout;

/**
 * Created by cenxiaozhong on 2017/5/12.
 * source CODE  https://github.com/Justson/AgentWebX5
 */

public interface LayoutParamsOffer<T extends FrameLayout.LayoutParams> {

    T offerLayoutParams();

}
