package com.just.agentwebX5;

/**
 * Created by cenxiaozhong on 2017/5/30.
 * source code https://github.com/Justson/AgentWebX5
 */

public interface WebLifeCycle {


    void onResume();
    void onPause();
    void onDestroy();


}
