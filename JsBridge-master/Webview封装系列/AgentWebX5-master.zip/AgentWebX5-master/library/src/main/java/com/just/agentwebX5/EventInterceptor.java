package com.just.agentwebX5;

/**
 * Created by cenxiaozhong on 2017/6/10.
 * source CODE  https://github.com/Justson/AgentWebX5
 */

public interface EventInterceptor {

    boolean event();

}
