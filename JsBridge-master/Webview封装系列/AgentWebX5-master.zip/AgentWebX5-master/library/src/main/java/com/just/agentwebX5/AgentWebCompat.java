package com.just.agentwebX5;

/**
 * Created by cenxiaozhong on 2017/5/24.
 */

public interface AgentWebCompat {
}
